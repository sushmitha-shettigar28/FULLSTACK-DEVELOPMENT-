from django.shortcuts import render
from datetime import datetime, timedelta

def datetime_offsets(request):
    current_time = datetime.now()
    four_hours_ahead = current_time + timedelta(hours=4)
    four_hours_behind = current_time - timedelta(hours=4)
    context = {
        'current_time': current_time,
        'four_hours_ahead': four_hours_ahead,
        'four_hours_behind': four_hours_behind
    }
    return render(request, 'datetime_offset_app/datetime_offsets.html', context)
