from django.shortcuts import render

def display_lists(request):
    fruits = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry']
    students = ['Sushmitha', 'Seetha', 'Surekha', 'Gani', 'Sudhi']
    context = {
        'fruits': fruits,
        'students': students
    }
    return render(request, 'list_app/display_lists.html', context)
